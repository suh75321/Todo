package com.teamsparta.todo.domain.dto

data class CommentDeleteDto(
    val id: Long,
    val authorName: String,
    val password: String
)
