package com.teamsparta.todo.domain.dto

data class TodoUpdateDto(
    val title: String,
    val content: String
)