package com.teamsparta.todo.domain.dto

import com.teamsparta.todo.domain.model.Member

data class MemberDto(
    val id: Long?,
    val email: String,
    val password: String,
) {
    companion object {
        fun from(member: Member): MemberDto {
            return MemberDto(member.id, member.email, member.password)
        }
    }
}