package com.teamsparta.todo.domain.login

data class LoginResponse(
    val accessToken: String
)